function cambioimagen(img){
	let imagengrande = document.getElementById("caja");
	imagengrande.src = img;
}